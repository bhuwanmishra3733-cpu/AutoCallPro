# AutoCall Pro — Android Studio starter project

Target device: Infinix Smart 8 HD (commonly sold with Android 13 Go / XOS 13).

## What is included
- Phone number field
- Adjustable call timer (5–180 seconds; default 25)
- START and STOP controls
- A starter `InCallService` implementation intended to disconnect a call after the timer and place another call immediately

## Important limitations
- This is **source code**, not a compiled APK. It has not been compiled or tested on your phone.
- Android call control is restricted. The app asks to be selected as the default Phone/Dialer app; Android may still restrict or behave differently with automatic call placement.
- Becoming the default dialer requires a proper, complete dialer experience. This starter implementation is not a production-quality dialer and may be rejected by some Android builds or behave inconsistently.
- Timer begins when Android reports the call to this service; it may not exactly match the first ring heard by the other party.
- If the OS/carrier rejects an automatic redial, the loop may stop. A true zero-second delay cannot be guaranteed.
- Use only for calls to people who expect your calls. Repeated calls can disturb others and may incur carrier charges. Press STOP to disable future redials.

## Build in Android Studio
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync and install the Android SDK requested by the project.
4. Connect your Infinix with USB debugging enabled, or use an emulator for a first build.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install the APK and test with a consenting contact.

## Notes for developers
This project uses a basic Android Activity and `InCallService`. A production app should implement the full default-dialer requirements, proper call UI, call lifecycle handling, permission/error UX, and device-specific tests before use.
