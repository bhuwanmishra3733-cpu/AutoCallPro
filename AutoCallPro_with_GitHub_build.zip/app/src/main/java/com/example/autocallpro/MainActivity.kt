package com.example.autocallpro

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var numberInput: EditText
    private lateinit var durationInput: EditText
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("autocall", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        numberInput.setText(prefs.getString("number", ""))
        durationInput.setText(prefs.getInt("duration", 25).toString())
        refreshStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "AutoCall Pro"
            textSize = 26f
        }, match())
        root.addView(TextView(this).apply {
            text = "Auto-redial setup • Infinix Smart 8 HD"
            textSize = 14f
        }, match())
        numberInput = EditText(this).apply {
            hint = "Phone number"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            singleLine = true
        }
        root.addView(numberInput, match())
        durationInput = EditText(this).apply {
            hint = "Ring/call duration in seconds (e.g. 25)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            singleLine = true
        }
        root.addView(durationInput, match())
        val defaultDialer = Button(this).apply {
            text = "Set as default phone app"
            setOnClickListener { requestDefaultDialer() }
        }
        root.addView(defaultDialer, match())
        val start = Button(this).apply {
            text = "START AUTO-REDIAL"
            setOnClickListener { startAutoRedial() }
        }
        root.addView(start, match())
        root.addView(Button(this).apply {
            text = "STOP"
            setOnClickListener {
                prefs.edit().putBoolean("running", false).apply()
                AutoCallInCallService.stopRedial()
                refreshStatus()
            }
        }, match())
        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, 18, 0, 0)
        }
        root.addView(status, match())
        root.addView(TextView(this).apply {
            text = "Important: Android/your carrier may block automatic call control. Test only with a person who expects your calls. STOP disables future redials; it cannot undo a call already placed."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        }, match())
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun requestDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 10)
            } else {
                status.text = "This app is already the default dialer, or the role is unavailable."
            }
        } else {
            status.text = "Set this app as the default Phone app in Android Settings."
            startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        }
    }

    private fun startAutoRedial() {
        val number = numberInput.text.toString().trim()
        val seconds = durationInput.text.toString().toIntOrNull() ?: 25
        if (number.length < 6 || seconds !in 5..180) {
            status.text = "Enter a valid phone number and duration from 5 to 180 seconds."
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), 11)
            status.text = "Allow phone-call permission, then press START again."
            return
        }
        val tm = getSystemService(TELECOM_SERVICE) as TelecomManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (!rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                status.text = "First tap 'Set as default phone app' and accept the Android prompt."
                return
            }
        }
        prefs.edit()
            .putString("number", number)
            .putInt("duration", seconds)
            .putBoolean("running", true)
            .apply()
        AutoCallInCallService.configure(applicationContext, number, seconds)
        try {
            val uri = Uri.fromParts("tel", number, null)
            tm.placeCall(uri, android.os.Bundle())
            status.text = "Auto-redial enabled. Target: $number • timer: $seconds sec. Press STOP to end the loop."
        } catch (e: Exception) {
            prefs.edit().putBoolean("running", false).apply()
            status.text = "Could not start call: ${e.javaClass.simpleName}. Check default-dialer role and permissions."
        }
    }

    private fun refreshStatus() {
        status.text = if (prefs.getBoolean("running", false))
            "Auto-redial is marked ON. Open the app and press STOP to disable future redials."
        else "Ready. Set a number and duration, then start."
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10) {
            status.text = if (resultCode == RESULT_OK) "Default phone role granted. You can configure a call."
            else "Default phone role was not granted. Automatic call control may not work."
        }
    }
}
