package com.example.autocallpro

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.TelecomManager

/**
 * Starter implementation. Android OEM/carrier behavior varies; this is not guaranteed
 * to disconnect/redial on every device. The user must set this app as the default dialer.
 */
class AutoCallInCallService : InCallService() {
    companion object {
        @Volatile private var appContext: Context? = null
        @Volatile private var targetNumber: String = ""
        @Volatile private var durationSeconds: Int = 25
        @Volatile private var enabled: Boolean = false
        private val handler = Handler(Looper.getMainLooper())
        private var currentCall: Call? = null
        private var callTimer: Runnable? = null
        private var retryRunnable: Runnable? = null
        private var lastDisconnectHandledAt = 0L

        fun configure(context: Context, number: String, seconds: Int) {
            appContext = context.applicationContext
            targetNumber = number
            durationSeconds = seconds
            enabled = true
        }

        fun stopRedial() {
            enabled = false
            callTimer?.let { handler.removeCallbacks(it) }
            retryRunnable?.let { handler.removeCallbacks(it) }
        }

        private fun scheduleDisconnectTimer(call: Call) {
            callTimer?.let { handler.removeCallbacks(it) }
            callTimer = Runnable {
                if (enabled && currentCall === call) {
                    try { call.disconnect() } catch (_: Exception) {}
                }
            }
            handler.postDelayed(callTimer!!, durationSeconds * 1000L)
        }

        private fun scheduleRedial() {
            if (!enabled || targetNumber.isBlank()) return
            val now = System.currentTimeMillis()
            if (now - lastDisconnectHandledAt < 800) return
            lastDisconnectHandledAt = now
            retryRunnable?.let { handler.removeCallbacks(it) }
            retryRunnable = Runnable {
                if (!enabled) return@Runnable
                val context = appContext ?: return@Runnable
                try {
                    val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                    tm.placeCall(Uri.fromParts("tel", targetNumber, null), Bundle())
                } catch (_: Exception) {
                    // If Android blocks a background redial, the loop stops rather than retrying aggressively.
                    enabled = false
                }
            }
            handler.post(retryRunnable!!)
        }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        currentCall = call
        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(changedCall: Call, state: Int) {
                if (currentCall !== changedCall) return
                when (state) {
                    Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_RINGING, Call.STATE_ACTIVE -> {
                        if (enabled) scheduleDisconnectTimer(changedCall)
                    }
                    Call.STATE_DISCONNECTED -> {
                        callTimer?.let { handler.removeCallbacks(it) }
                        currentCall = null
                        if (enabled) scheduleRedial()
                    }
                }
            }
        })
        if (enabled) scheduleDisconnectTimer(call)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        if (currentCall === call) {
            callTimer?.let { handler.removeCallbacks(it) }
            currentCall = null
            if (enabled) scheduleRedial()
        }
    }
}
